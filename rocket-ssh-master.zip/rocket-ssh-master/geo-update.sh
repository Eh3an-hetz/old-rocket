#!/bin/bash
Month=$(date +"%m")
Year=$(date +"%Y")
wget https://download.db-ip.com/free/dbip-country-lite-${Year}-${Month}.csv.gz -O /usr/share/xt_geoip/dbip-country-lite.csv.gz
gunzip /usr/share/xt_geoip/dbip-country-lite.csv.gz
/usr/lib/xtables-addons/xt_geoip_build -D /usr/share/xt_geoip/ -S /usr/share/xt_geoip/
rm /usr/share/xt_geoip/dbip-country-lite.csv
 
